<?php 
	
	$hname = 'localhost';
	$uname = 'your_postgres_username'; // Replace 'your_postgres_username' with your PostgreSQL username
	$pass = 'your_postgres_password'; // Replace 'your_postgres_password' with your PostgreSQL password
	$db = 'hbwebsite';

	$con = pg_connect("host=$hname dbname=$db user=$uname password=$pass");

	if (!$con) {
		die("Cannot Connect to Database" . pg_last_error());
	}

	function filteration($data){
		foreach ($data as $key => $value) {
			$data[$key] = trim($value);
			$data[$key] = stripcslashes($value);
			$data[$key] = htmlspecialchars($value);
			$data[$key] = strip_tags($value);
		}
		return $data;
	}

	function select($sql,$values,$datatypes)
	{
		$con = $GLOBALS['con'];
		$stmt = pg_prepare($con, "", $sql);
		if ($stmt) {
			$result = pg_execute($con, "", $values);	
		} else {
			die("Query cannot be executed - Select");
		}
	}
?>
